package techstore;

public class Personne {
	private static String cin;
	private static String nom;
	private static String prenom;
	private static Adresse adresse;
	public Personne(String cin,String nom,String prenom,Adresse adr)
	{
		this.cin=cin;
		this.nom=nom;
		this.prenom=prenom;
		this.adresse=adr;
		
	}
	public Personne(String cin,String nom,String prenom,String gouv,int codeP)
	{
		this.cin=cin;
		this.nom=nom;
		this.prenom=prenom;
		this.adresse=new Adresse(gouv,codeP);
	}
	public void setCin()
	{
		this.cin=cin;
	}
	public  String getCin()
	{
		return cin;
	}
	public String getNom()
	{
		return nom;
	}
	public String getPrenom()
	{
		return prenom;
	}
	public Adresse getAdresse()
	{
		return adresse;
	}
	public void setNom(String nom)
	{
		this.nom=nom;
	}
	public void setPrenom(String prenom)
	{
		this.prenom=prenom;
	}
	public void setAdresse(Adresse adr)
	{
		this.adresse=adr;
	}
	public String toString()
	{
		return "cin ="+this.cin+",nom="+this.nom+",prenom="+this.prenom+",adresse"+this.adresse.toString();
		
	}
	
	}
