package techstore;

public class Article {
	private static int compteur = 0;
	private int id;
	private String nom;
	private String reference;
	private double prix;
	
	public Article(String nom,double prix) {
		compteur++;
        this.id = compteur;
        this.nom = nom;
        this.prix = prix;
        genererReference();
	}
	private void genererReference() {
        String nomSansEspace = this.nom.replace(" ", "");
        String ref = "";
        for (int i = 0; i < nomSansEspace.length(); i++) {
            if (i % 5 == 0) {
                ref += nomSansEspace.charAt(i);
            }
        }
        this.reference = ref + this.id;
    }
	public int getId() {
		return this.id;
	}
	public String getReference() {
		return this.reference;
	}
	public String getNom() {
		return this.nom;
	}
	public double getPrix() {
		return this.prix;
	}
	public void setReference(String refrence) {
		this.reference=refrence;
	}
	public void setNom(String nom) {
		this.nom=nom;
	}
	public void setPrix(double prix) {
		this.prix=prix;
	}
	public void modifier(String nom) {
        this.nom = nom;
        genererReference();
    }
	public void modifier(String nom, double prix) {
        this.nom = nom;
        this.prix = prix;
        genererReference();
    }

    public String toString() {
        return "id=" + this.id + ", nom=" + this.nom + ", reference=" + this.reference + ", prix=" + this.prix;
    }
}