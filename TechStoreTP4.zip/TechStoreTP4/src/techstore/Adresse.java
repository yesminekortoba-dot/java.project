package techstore;

public class Adresse {

	private static String gouvernerat;
	private static int CodePostal;
	public Adresse(String gouv,int codeP)
	{
		this.gouvernerat=gouv;
		this.CodePostal=codeP;
		
	}
	public String getGouvernerat()
	{
		return gouvernerat;
	}
	public void setGouvernereat(String gouv)
	{
		this.gouvernerat=gouv;
	}
	public int getCodePostal()
	{
		return CodePostal;
	}
	public void setCodePostal(int codeP)
	{
		this.CodePostal=codeP;
	}
	public String toString()
	{
		return "Adresse[gouvernerat:"+this.gouvernerat+"code postal:"+this.CodePostal+"]";
		
	}
}
