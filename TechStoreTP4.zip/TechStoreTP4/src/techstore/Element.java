package techstore;

public class Element {
    private Article article;
    private long quantite;

    public Element(Article article, long quantite) {
        this.article = article;
        if (quantite < 0) {
            this.quantite = 0;
        } else {
            this.quantite = quantite;
        }
    }

    public Element(String nom, double prix, long quantite) {
        this.article = new Article(nom, prix);
        if (quantite < 0) {
            this.quantite = 0;
        } else {
            this.quantite = quantite;
        }
    }

    public Article getArticle() {
        return this.article;
    }

    public long getQuantite() {
        return this.quantite;
    }

    public String getReferenceArticle() {
        return this.article.getReference();
    }

    public String getNomArticle() {
        return this.article.getNom();
    }

    public double getPrixArticle() {
        return this.article.getPrix();
    }

    public void setArticle(Article article) {
        this.article = article;
    }

    public void setQuantite(long quantite) {
        if (quantite >= 0) {
            this.quantite = quantite;
        }
    }

    public void incrementerQuantite(long quantite) {
        if (quantite > 0) {
            this.quantite += quantite;
        }
    }

    public void decrementerQuantite(long quantite) {
        if (quantite > 0 && this.quantite >= quantite) {
            this.quantite -= quantite;
        }
    }

    public void modifier(String nom, double prix, long quantite) {
        this.article = new Article(nom, prix);
        if (quantite >= 0) {
            this.quantite = quantite;
        }
    }

    public boolean equals(String reference) {
        if (this.article != null && reference != null) {
            return this.article.getReference().equals(reference);
        }
        return false;
    }

    public boolean equals(Article article) {
        if (this.article != null && article != null) {
            return this.article.getReference().equals(article.getReference());
        }
        return false;
    }

    public String toString() {
        return "Element [article=" + this.article + ", quantite=" + this.quantite + "]";
    }
}